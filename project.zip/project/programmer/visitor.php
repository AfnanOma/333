<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="programLogin.css">
    <title>Login Page</title>
</head>

<body>
<img class="log-img" src="../images/4.png" alt="4 Image">

    <div class="right-side">
        <h1>تسجيل الدخول</h1>
        <div class="login-form">
        <?php
 $servername = "localhost";
$username = "root";
$password = "";  
$dbname = "proj_database";  

 $conn = new mysqli($servername, $username, $password, $dbname);

 if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
 if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Access form data
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);
    
     $age = null;

     if (isset($_POST["age"])) {
        $age = mysqli_real_escape_string($conn, $_POST["age"]);
    }

     $checkUserQuery = "SELECT * FROM users WHERE username = '$username'";
    $result = $conn->query($checkUserQuery);
    $usernameExistsError = " ";
    if ($result->num_rows > 0) {
        $usernameExistsError = "Username already exists. Please choose a different username.";
    } else {
         $type = "visitor";

         $sql = "INSERT INTO users (username, password, type, age) VALUES ('$username', '$password', '$type', '$age')";

        if ($conn->query($sql) === TRUE) {
            echo "Data inserted successfully.";

             header("Location: visitorhome.html");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

 $conn->close();
?>

 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <label for="username"><h1>اسم المسنخدم</h1> </label>
    <input type="text" id="username" name="username" required>

    <label for="password"> <h1>كلمة المرور</h1></label>
    <input type="password" id="password" name="password" required>

    <?php 
    if (isset($usernameExistsError) && !empty($usernameExistsError)) {
        echo '<p class="error-message">' . $usernameExistsError . '</p>';
    }
    ?>

    <button type="submit"> <h2>تسجيل الدخول</h2></button>
    <p>ليس لديك حساب بالفعل؟ <a href="visitorLogin.php">انقر هنا للدخول</a></p>

</form>

        </div>
       
    </div>
</body>

</html>
