<?php
// Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // No password in your case
$dbname = "proj_database"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Access form data
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $password = mysqli_real_escape_string($conn, $_POST["password"]);

    // Check if the provided username and password match a record in the "users" table
    $checkLoginQuery = "SELECT * FROM users WHERE username = '$username' AND password = '$password'";
    $result = $conn->query($checkLoginQuery);

    if ($result->num_rows > 0) {
        // Login successful
        echo "Login successful. Redirecting...";
        // Add any additional logic or redirection here

        // For example, redirecting to a home page
        header("Location: prog.html");
        exit();
    } else {
        // Login failed
        $loginError = "خطأ في اسم المستخدم أو كلمة مرور. حاول مرة اخرى.";
    }
}

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="programLogin.css">
    <title>Login Page</title>
</head>

<body>
    <div class="left-side">
        
 <img class="log-img" src="../images/program.png" alt="Program Image">

    </div>

    <div class="right-side">
        <h1>تسجيل الدخول</h1>
        <div class="login-form">
            <?php
            // Display login error message
            if (isset($loginError) && !empty($loginError)) {
                echo '<p class="error-message">' . $loginError . '</p>';
            }
            ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <label for="username">اسم المستخدم</label>
                <input type="text" id="username" name="username" required>

                <label for="password">كلمة المرور</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">تسجيل الدخول</button>
              
            </form>
        </div>
    </div>
</body>

</html>
