<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="programLogin.css">
    <title>Login Page</title>
</head>

<body>
    <div class="left-side">
        <img class="log-img" src="../images/program1.jpg" alt="Program Image">
    </div>
    <div class="right-side">
        <h1>تسجيل الدخول</h1>
        <div class="login-form">
            <?php
            // Database connection parameters
$servername = "localhost";
$username = "root";
$password = ""; // No password in your case
$dbname = "proj_database"; // Replace with your actual database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


            // Handle form submission
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Access form data
                $username = mysqli_real_escape_string($conn, $_POST["username"]);
                $password = mysqli_real_escape_string($conn, $_POST["password"]);

                // Insert data into the "users" table
                $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";

                if ($conn->query($sql) === TRUE) {
                    echo "Data inserted successfully.";
                } else {
                    echo "Error: " . $sql . "<br>" . $conn->error;
                }
            }

            // Close the database connection
            $conn->close();
            ?>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <label for="username">اسم المستخدم</label>
                <input type="text" id="username" name="username" required>

                <label for="password">كلمة المرور</label>
                <input type="password" id="password" name="password" required>

                <button type="submit">تسجيل الدخول</button>
            </form>
        </div>
        <div class="form-group">
            <a href="https://github.com/">GITHUB</a>
        </div>
    </div>
<!-- Code injected by live-server -->
<script>
	// <![CDATA[  <-- For SVG support
	if ('WebSocket' in window) {
		(function () {
			function refreshCSS() {
				var sheets = [].slice.call(document.getElementsByTagName("link"));
				var head = document.getElementsByTagName("head")[0];
				for (var i = 0; i < sheets.length; ++i) {
					var elem = sheets[i];
					var parent = elem.parentElement || head;
					parent.removeChild(elem);
					var rel = elem.rel;
					if (elem.href && typeof rel != "string" || rel.length == 0 || rel.toLowerCase() == "stylesheet") {
						var url = elem.href.replace(/(&|\?)_cacheOverride=\d+/, '');
						elem.href = url + (url.indexOf('?') >= 0 ? '&' : '?') + '_cacheOverride=' + (new Date().valueOf());
					}
					parent.appendChild(elem);
				}
			}
			var protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://';
			var address = protocol + window.location.host + window.location.pathname + '/ws';
			var socket = new WebSocket(address);
			socket.onmessage = function (msg) {
				if (msg.data == 'reload') window.location.reload();
				else if (msg.data == 'refreshcss') refreshCSS();
			};
			if (sessionStorage && !sessionStorage.getItem('IsThisFirstTime_Log_From_LiveServer')) {
				console.log('Live reload enabled.');
				sessionStorage.setItem('IsThisFirstTime_Log_From_LiveServer', true);
			}
		})();
	}
	else {
		console.error('Upgrade your browser. This Browser is NOT supported WebSocket for Live-Reloading.');
	}
	// ]]>
</script>
</body>

</html>
