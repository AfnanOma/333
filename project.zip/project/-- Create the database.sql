-- Create the database
CREATE DATABASE IF NOT EXISTS proj_database CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

-- Switch to the newly created database
USE proj_database;

-- Create the 'comments' table
CREATE TABLE IF NOT EXISTS comments (
  comment_id int(11) NOT NULL AUTO_INCREMENT,
  comment text NOT NULL,
  username varchar(255) NOT NULL,
  PRIMARY KEY (comment_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert data into the 'comments' table
INSERT INTO comments (comment_id, comment, username) VALUES
(2, 'sdfddddd', ''),
(3, 'sdf', '');

-- Create the 'users' table
CREATE TABLE IF NOT EXISTS users (
  id int(11) NOT NULL AUTO_INCREMENT,
  username varchar(255) NOT NULL,
  password varchar(255) NOT NULL,
  type varchar(255) NOT NULL,
  age int(11) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Insert data into the 'users' table
INSERT INTO users (id, username, password, type, age) VALUES

