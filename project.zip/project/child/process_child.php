<?php
// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start a session
session_start();

// Database connection parameters
$servername = "localhost";
$username = "admin";
$password = ""; // No password in your case
$dbname = "proj_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST["username"]);
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT); // Hash the password
    $type = mysqli_real_escape_string($conn, $_POST["type"]);
    $age = mysqli_real_escape_string($conn, $_POST["age"]);

    // Use prepared statements to prevent SQL injection
    $stmt = $conn->prepare("INSERT INTO users (username, password, type, age) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("sssi", $username, $password, $type, $age);

    if ($stmt->execute()) {
        // Store the username in the session
        
        $_SESSION['username'] = $username;

         header("Location: childHome.html");
        exit();  
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
 
$conn->close();
?>

