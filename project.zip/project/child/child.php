<!DOCTYPE html>
<html lang="ar">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Child Login</title>
    <link rel="stylesheet" type="text/css" href="child.css">
</head>

<body>


    <div class="login-container">
        <div class="image-bottom-right">
            <img src="../images/right_image.png" alt="Bottom Right Image">
        </div>
        <div class="image-top-left">
            <img src="../images/left_image.png" alt="Top Left Image">
        </div>
        
        <?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proj_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $child_name = mysqli_real_escape_string($conn, $_POST["username"]);
    $child_age = mysqli_real_escape_string($conn, $_POST["age"]);
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);

    // Check if the username already exists
    $check_user_query = "SELECT * FROM users WHERE username = '$child_name'";
    $result = $conn->query($check_user_query);

    if ($result->num_rows > 0) {
        echo "Error:اسم المستخدم موجود بالفعل. يرجى اختيار اسم مستخدم مختلف.";
    } else {
        // Username doesn't exist, proceed with insertion
        $sql = "INSERT INTO users (username, password, type, age) VALUES ('$child_name', '$password', 'child', '$child_age')";

        if ($conn->query($sql) === TRUE) {
            session_start();
            $_SESSION['username'] = $child_name;
            $_SESSION['type'] = 'child';

            header("Location: childHome.html");
            exit();
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
    <h2>تسجيل جديد</h2>
    <label for="username">ادخل الاسم</label>
    <input type="text" id="username" name="username" required>

    <label for="password">ادخل كلمة المرور</label>
    <input type="password" id="password" name="password" required>

    <label for="age">ادخل عمزك</label>
    <input type="number" id="age" name="age" required min="9" max="11">

    <button type="submit">دخول</button>
    <p>  لديك حساب بالفعل؟ <a href="childLogin.php">انقر هنا للدخول</a></p>

</form>

    </div>

    <script>
        // Retrieve username from PHP session
        <?php
        if (isset($_SESSION['username'])) {
            echo 'var storedUsername = "' . $_SESSION['username'] . '";';
            echo 'console.log("Username from PHP session: " + storedUsername);';
        }
        ?>
    </script>
</body>

</html>
