document.addEventListener("DOMContentLoaded", function () {
    const video = document.getElementById("video");
    const optionsContainer = document.querySelector(".qustion");
    const img = document.getElementById("img-bg");
     
    let currentVideoIndex = 0;
    const videoData = [
        { name: "asaad", options: [ "اسد", "فهد"], correctAnswer: "اسد",bgImg:'1' },
        { name: "ghazal", options: ["فهد", "جمل"], correctAnswer: "فهد" ,bgImg:'c'},
        { name: "fahd", options: [ "غزال","فهد"], correctAnswer: "غزال",bgImg:'2' },
        { name: "thauban", options: [ "سلحفاه","ثعبان" ], correctAnswer: "ثعبان",bgImg:'s' },
        { name: "zeeb", options: ["ذيب", "فيل"], correctAnswer: "ذيب",bgImg:'3' }
    ];

    function loadNextVideo() {
        if (currentVideoIndex < videoData.length) {
            const nextVideo = videoData[currentVideoIndex];
            video.src = `../../../images/gussegame/${nextVideo.name}.mp4`;
            img.src =`../../../images/gussegame/${nextVideo.bgImg}.png`
            optionsContainer.innerHTML = "";
 
            nextVideo.options.forEach((optionText, index) => {
                const option = document.createElement("div");
                option.classList.add("option");
                option.textContent = optionText;
                option.addEventListener("click", function () {
                    handleOptionClick(optionText, nextVideo.correctAnswer);
                });
                optionsContainer.appendChild(option);
            });

            currentVideoIndex++;
        } else {

            playSuccessSound();
            alert("مبروك لقد اكملت اللعبه بنجاح!!!!!");
            window.location.href = "gussstartpage.html";
        }
    }

    function handleOptionClick(selectedAnswer, correctAnswer) {
        console.log(selectedAnswer)
        if (selectedAnswer === correctAnswer) {
            loadNextVideo();
        } else {
            alert("اجابة خاطئة حاول مرة اخرى!");
        }
    }
    function playSuccessSound() {
        const successSound = document.getElementById("successSound");
        if (successSound) {
            successSound.play();
        }
    }
    loadNextVideo();
});
