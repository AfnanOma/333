<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Database connection parameters
    $servername = "localhost";
    $username = "admin";
    $password = "";
    $dbname = "proj_database";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $comment = mysqli_real_escape_string($conn, $_POST["comment"]);
    $username = $_SESSION['username'];

    // Insert data into the database
    $sql = "INSERT INTO comments (comment, username) VALUES ('$comment', '$username')";

    if ($conn->query($sql) === TRUE) {
        // Get the ID of the inserted comment
        $commentId = $conn->insert_id;

        // Return a JSON response with the comment ID
        $response = array('comment_id' => $commentId);
        echo json_encode($response);
    } else {
        // Return an error response to the client
        echo json_encode(array('error' => "Error: " . $sql . "<br>" . $conn->error));
    }

    // Close the database connection
    $conn->close();
}
?>
