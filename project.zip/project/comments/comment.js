document.addEventListener("DOMContentLoaded", function () {
    console.log("dddddddddd");
    var commentInput = document.getElementById('commentInput');
    var displayedComments = document.getElementById('displayedComments');
    var commentButton = document.querySelector('.add-comment-section button');

    commentButton.addEventListener('click', addComment);

    function addComment() {
        var newCommentText = commentInput.value.trim();

        if (newCommentText !== '') {
            sendRequest('POST', 'comments.php', 'action=save_comment&comment=' + encodeURIComponent(newCommentText), fetchAndDisplayComments);
        }
    }

    function removeComment(commentId) {
        sendRequest('POST', 'comments.php', 'action=remove_comment&comment_id=' + commentId, fetchAndDisplayComments);
    }

    function fetchAndDisplayComments() {
        sendRequest('GET', 'comments.php', null, function (response) {
            var comments = JSON.parse(response);
            updateDisplayedComments(comments);
        });
    }

    function updateDisplayedComments(comments) {
        displayedComments.innerHTML = '';

        comments.forEach(function (comment) {
            var commentElement = document.createElement('div');
            commentElement.className = 'comment-text';
            commentElement.textContent = comment.comment;

            var removeButton = document.createElement('button');
            removeButton.textContent = 'Remove';
            removeButton.className = 'btn btn-danger btn-sm';
            removeButton.addEventListener('click', function () {
                removeComment(comment.comment_id);
            });
            displayedComments.appendChild(commentElement);
        });
    }

    function sendRequest(method, url, data, callback) {
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function () {
            if (xhr.readyState === 4 && xhr.status === 200) {
                callback(xhr.responseText);
            }
        };

        xhr.open(method, url, true);

        if (method === 'POST') {
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        }

        xhr.send(data);
    }

    fetchAndDisplayComments();
});
