<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "proj_database";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"])) {
    handlePostRequest($conn);
} elseif ($_SERVER["REQUEST_METHOD"] == "GET") {
    handleGetRequest($conn);
}

$conn->close();

function handlePostRequest($conn) {
    if ($_POST["action"] == "save_comment") {
        saveComment($conn);
    } elseif ($_POST["action"] == "remove_comment") {
        removeComment($conn);
    }
}

function saveComment($conn) {
    $commentText = mysqli_real_escape_string($conn, $_POST["comment"]);
    $sql = "INSERT INTO comments (comment) VALUES ('$commentText')";

    if ($conn->query($sql) === TRUE) {
        echo "Comment saved successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

function removeComment($conn) {
    $commentId = mysqli_real_escape_string($conn, $_POST["comment_id"]);
    $sql = "DELETE FROM comments WHERE comment_id = $commentId";

    if ($conn->query($sql) === TRUE) {
        echo "Comment removed successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

function handleGetRequest($conn) {
    $sql = "SELECT * FROM comments";
    $result = $conn->query($sql);

    $comments = array();

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $comments[] = array(
                'comment_id' => $row['comment_id'],
                'comment' => $row['comment']
            );
        }
    }

    echo json_encode($comments);
}
?>
